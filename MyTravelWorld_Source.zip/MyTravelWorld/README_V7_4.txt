MyTravelWorld V7.4 — Globe intégré
Les ressources du globe sont téléchargées pendant le build GitHub puis incluses dans l'APK.
Le workflow GitHub main.yml déjà créé peut rester inchangé.
