import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mytravelworld.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mytravelworld.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}


val prepareOfflineGlobe by tasks.registering {
    val vendorDir = file("src/main/assets/vendor")
    outputs.dir(vendorDir)
    doLast {
        vendorDir.mkdirs()
        val files = mapOf(
            "three.min.js" to "https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.min.js",
            "globe.gl.min.js" to "https://cdn.jsdelivr.net/npm/globe.gl@2.45.5/dist/globe.gl.min.js",
            "topojson-client.min.js" to "https://cdn.jsdelivr.net/npm/topojson-client@3.1.0/dist/topojson-client.min.js",
            "exifr.umd.js" to "https://cdn.jsdelivr.net/npm/exifr@7.1.3/dist/full.umd.js",
            "countries-110m.json" to "https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-110m.json",
            "earth-blue-marble.jpg" to "https://cdn.jsdelivr.net/npm/three-globe@2.45.0/example/img/earth-blue-marble.jpg",
            "earth-topology.png" to "https://cdn.jsdelivr.net/npm/three-globe@2.45.0/example/img/earth-topology.png"
        )
        files.forEach { (name, address) ->
            val out = vendorDir.resolve(name)
            if (!out.exists() || out.length() == 0L) {
                URL(address).openStream().use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(prepareOfflineGlobe) }
