MyTravelWorld V7.5

Corrections principales :
- WebViewAssetLoader : les ressources locales sont servies via
  https://appassets.androidplatform.net/ au lieu de file://.
- Le globe, les textures, les données pays et les bibliothèques sont intégrés à l'APK.
- Meilleure gestion des barres système Samsung/Android.
- Interface plus compacte sur petit écran.
- Version Android : versionCode 75 / versionName 0.7.5.
- Badge V7.5 visible dans le titre de l'application.

Le workflow GitHub existant peut rester inchangé.
