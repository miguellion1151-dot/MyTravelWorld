MYTRAVELWORLD V7.1 — OUVERTURE DANS ANDROID STUDIO

1. Décompresse ce ZIP sur ton ordinateur.
2. Ouvre Android Studio.
3. Clique sur Open et sélectionne le dossier "MyTravelWorld" (celui qui contient settings.gradle.kts).
4. Si Android Studio propose d'installer Android SDK 35 ou d'autres composants, accepte.
5. Attends la fin de la synchronisation Gradle.
6. Pour tester avec ton téléphone :
   - active les Options développeur et le Débogage USB sur le téléphone ;
   - branche-le en USB ;
   - sélectionne ton téléphone dans Android Studio ;
   - clique sur Run (triangle vert).
7. Pour créer un APK : Build > Build App Bundle(s) / APK(s) > Build APK(s).
8. Le fichier se trouve normalement dans : app/build/outputs/apk/debug/app-debug.apk

REMARQUES
- Une connexion Internet est nécessaire au premier chargement de certaines ressources du globe 3D.
- Les photos et voyages sont conservés localement par l'application WebView.
- Les coordonnées GPS ne sont disponibles que si la photo possède réellement des métadonnées EXIF GPS.
